#include "buzzer.h"

int cycle_time = 0;

void init_buzzer()
{
    gpio_init(BUZZER_PIN);
    gpio_set_dir(BUZZER_PIN, GPIO_OUT);
}

void play()
{
        cycle_time += 1;
        cycle_time %= 100;
        if(cycle_time < 10)
        gpio_put(BUZZER_PIN, 1);
        else
        gpio_put(BUZZER_PIN, 0);
}

void stop()
{
        gpio_put(BUZZER_PIN, 0);
}