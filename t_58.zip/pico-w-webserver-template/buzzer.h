#ifndef BUZZER_H
#define BUZZER_H
#include "pico/stdlib.h"
#include <stdio.h>

#define BUZZER_PIN 2
extern int cycle_time;

void init_buzzer();
void play();
void stop();

#endif // BUZZER_H
